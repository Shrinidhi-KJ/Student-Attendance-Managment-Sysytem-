 <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span> &copy; <script> document.write(new Date().getFullYear()); </script> 
            </span>
          </div>
        </div>
      </footer>